import { useRef } from 'react'
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion'

export function Marquee({ items, className = '', speed = 28 }) {
  const doubled = [...items, ...items]
  return (
    <div className={`overflow-hidden whitespace-nowrap select-none ${className}`}>
      <motion.div
        className="inline-flex items-center gap-4"
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: speed, ease: 'linear', repeat: Infinity }}
      >
        {doubled.map((it, i) => (
          <span key={i} className="inline-flex items-center gap-4 font-display text-5xl md:text-7xl font-semibold text-ink/10">
            {it} <span className="text-violet text-4xl">✦</span>
          </span>
        ))}
      </motion.div>
    </div>
  )
}

export function Blob({ className = '', colorFrom = '#8C7EF5', colorTo = '#D8FF4F', animate = true }) {
  return (
    <motion.div
      className={`rounded-full blur-[2px] ${className}`}
      style={{
        background: `radial-gradient(circle at 35% 30%, ${colorFrom}, ${colorTo} 120%)`,
      }}
      animate={animate ? { y: [0, -14, 0], rotate: [0, 6, 0] } : {}}
      transition={{ duration: 6, repeat: Infinity, ease: 'easeInOut' }}
    />
  )
}

export function Sphere({ className = '' }) {
  return (
    <motion.div
      className={`rounded-full ${className}`}
      style={{
        background: 'radial-gradient(circle at 32% 28%, #6b6b6b, #0a0a0a 70%)',
        boxShadow: '0 20px 60px -10px rgba(0,0,0,0.5), inset 0 0 30px rgba(255,255,255,0.06)',
      }}
      animate={{ y: [0, -16, 0] }}
      transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
    />
  )
}

export function BrowserCard({ title, tag, accent = 'bg-white', textClass = 'text-ink', className = '', children, dark = false, image }) {
  return (
    <div
      className={`relative rounded-2xl border ${dark ? 'border-white/10' : 'border-line'} ${accent} overflow-hidden flex flex-col ${className}`}
    >
      {image && (
        <>
          <img
            src={image}
            alt=""
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        </>
      )}
      <div className={`relative z-10 flex items-center justify-between px-4 py-3 ${image ? 'text-white/80' : dark ? 'text-white/70' : 'text-ink/60'}`}>
        <div className="flex items-center gap-2 text-xs">
          <span className={`w-5 h-5 rounded-full ${image || dark ? 'bg-white/15' : 'bg-ink/10'} flex items-center justify-center`}>●</span>
          {title}
        </div>
        <div className="flex items-center gap-2">
          {tag && (
            <span className="text-[10px] border border-current/30 rounded-full px-2 py-0.5">{tag}</span>
          )}
          <span>≡</span>
        </div>
      </div>
      <div className={`relative z-10 flex-1 px-4 pb-4 ${image ? 'text-white' : textClass}`}>{children}</div>
    </div>
  )
}

/**
 * TiltCard — wraps children in a subtle, spring-based 3D tilt that follows
 * the cursor. This is the "advanced" hover interaction used across the
 * showcase grids instead of a flat translateY hover.
 */
export function TiltCard({ children, className = '', maxTilt = 8 }) {
  const ref = useRef(null)
  const x = useMotionValue(0)
  const y = useMotionValue(0)
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [maxTilt, -maxTilt]), {
    stiffness: 220,
    damping: 20,
  })
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-maxTilt, maxTilt]), {
    stiffness: 220,
    damping: 20,
  })
  const glowX = useTransform(x, [-0.5, 0.5], ['0%', '100%'])
  const glowY = useTransform(y, [-0.5, 0.5], ['0%', '100%'])

  const handleMove = (e) => {
    const rect = ref.current.getBoundingClientRect()
    x.set((e.clientX - rect.left) / rect.width - 0.5)
    y.set((e.clientY - rect.top) / rect.height - 0.5)
  }
  const handleLeave = () => {
    x.set(0)
    y.set(0)
  }

  return (
    <motion.div
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ rotateX, rotateY, transformStyle: 'preserve-3d', transformPerspective: 800 }}
      whileHover={{ scale: 1.03, z: 20 }}
      transition={{ type: 'spring', stiffness: 260, damping: 22 }}
      className={`relative ${className}`}
    >
      <motion.div
        className="pointer-events-none absolute inset-0 rounded-[inherit] opacity-0 hover:opacity-100 transition-opacity duration-300 z-20"
        style={{
          background: useTransform(
            [glowX, glowY],
            ([gx, gy]) => `radial-gradient(circle at ${gx} ${gy}, rgba(255,255,255,0.35), transparent 60%)`
          ),
        }}
      />
      {children}
    </motion.div>
  )
}

export function SectionLabel({ children }) {
  return (
    <p className="text-sm text-violet font-medium mb-3 flex items-center gap-1.5">
      <span className="w-1.5 h-1.5 rounded-full bg-violet inline-block" /> {children}
    </p>
  )
}
