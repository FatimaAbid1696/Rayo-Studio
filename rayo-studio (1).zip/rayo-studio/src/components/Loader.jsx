import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'

export default function Loader({ onDone }) {
  const [count, setCount] = useState(0)
  const [exiting, setExiting] = useState(false)

  useEffect(() => {
    let raf
    const start = performance.now()
    const duration = 1900

    const tick = (now) => {
      const elapsed = now - start
      const progress = Math.min(elapsed / duration, 1)
      // ease-out-ish curve so it feels alive, not linear
      const eased = 1 - Math.pow(1 - progress, 2)
      setCount(Math.round(eased * 100))
      if (progress < 1) {
        raf = requestAnimationFrame(tick)
      } else {
        setTimeout(() => setExiting(true), 250)
      }
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
  }, [])

  useEffect(() => {
    if (exiting) {
      const t = setTimeout(onDone, 900)
      return () => clearTimeout(t)
    }
  }, [exiting, onDone])

  return (
    <AnimatePresence>
      {!exiting ? (
        <motion.div
          key="loader"
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-[100] bg-ink flex flex-col items-center justify-center"
        >
          <div className="relative overflow-hidden">
            <motion.span
              key={count}
              initial={{ y: 28, opacity: 0, scale: 0.9 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              className="font-display font-semibold text-cream text-[18vw] leading-none tabular-nums block"
            >
              {count}
              <span className="text-violet-light text-[6vw] align-top ml-2">%</span>
            </motion.span>
          </div>
          <div className="mt-8 w-[60vw] max-w-md h-[2px] bg-white/10 overflow-hidden rounded-full">
            <motion.div
              className="h-full bg-lime"
              animate={{ width: `${count}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
          <p className="mt-6 text-white/40 text-xs tracking-wide font-body">
            loading rayostudio experience
          </p>
        </motion.div>
      ) : null}
    </AnimatePresence>
  )
}
