import { motion } from 'framer-motion'
import { IMG } from '../data/images'

const cards = [
  { title: 'Clients Approved', img: IMG.meeting },
  { title: 'AI-powered solutions', sub: 'Fintech · Blockchain · Cybersecurity · Gaming', img: IMG.laptopCode, dark: true },
  { title: 'Awards & publications', sub: 'Behance curated work', img: IMG.designTools },
  { title: 'Imagination + the power of it', img: IMG.abstract3 },
  { title: 'My journal', img: IMG.coffee },
  { title: 'Corporate websites', sub: 'eCommerce · Mobile Apps', img: IMG.ecommerce },
  { title: '30+ Awards', sub: '3+ years experience', img: IMG.workspace2 },
]

export default function StatsMarquee() {
  const doubled = [...cards, ...cards]
  return (
    <section className="py-8 overflow-hidden">
      <motion.div
        className="flex gap-5 w-max"
        animate={{ x: ['0%', '-50%'] }}
        transition={{ duration: 42, repeat: Infinity, ease: 'linear' }}
      >
        {doubled.map((c, i) => (
          <div
            key={i}
            className="relative w-64 h-56 rounded-2xl border border-line overflow-hidden flex flex-col justify-between shrink-0"
          >
            <img src={c.img} alt="" loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/10 to-black/5" />
            <span className="relative z-10 text-xs text-white/70 p-5">rayo template</span>
            <div className="relative z-10 p-5">
              <p className="font-display text-lg font-semibold leading-snug text-white">{c.title}</p>
              {c.sub && <p className="text-xs text-white/70 mt-1">{c.sub}</p>}
            </div>
          </div>
        ))}
      </motion.div>
    </section>
  )
}
