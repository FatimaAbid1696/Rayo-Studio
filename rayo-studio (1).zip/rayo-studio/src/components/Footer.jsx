import { motion } from 'framer-motion'

const columns = [
  { title: 'Menu', links: ['Home', 'About us', 'Works', 'Services', 'Insights', 'Contact'] },
  { title: 'Contact', links: ['hello@rayostudio.com', '+1 212-708-9400'] },
  { title: 'Ecosystem', links: ['Dribbble', 'Behance', 'Instagram', 'Github', 'Codepen', 'Figma Community'] },
]

export default function Footer() {
  return (
    <footer className="px-6 md:px-10 max-w-[1400px] mx-auto pb-10">
      <motion.h2
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.8 }}
        className="font-display font-semibold text-[16vw] md:text-[8rem] leading-none text-center"
      >
        rayostudio
      </motion.h2>

      <div className="grid md:grid-cols-3 gap-8 border-t border-line pt-10 mt-6">
        {columns.map((c) => (
          <div key={c.title}>
            <p className="text-xs text-ink/40 mb-3">{c.title}</p>
            <ul className="space-y-2">
              {c.links.map((l) => (
                <li key={l}>
                  <a href="#" className="text-sm hover:text-violet transition-colors duration-200">{l}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="mt-10 pt-6 border-t border-line flex flex-col sm:flex-row justify-between items-center gap-3 text-xs text-ink/40">
        <div className="flex gap-6">
          <a href="#" className="hover:text-ink transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-ink transition-colors">Terms & Conditions</a>
        </div>
        <span>Mix_Design © 2026</span>
      </div>
    </footer>
  )
}
