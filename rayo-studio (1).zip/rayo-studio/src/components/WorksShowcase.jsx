import { motion } from 'framer-motion'
import { Marquee, SectionLabel, TiltCard } from './UI'
import { IMG } from '../data/images'

const demos = [
  { n: '01', name: 'Main Home', img: IMG.workspace1 },
  { n: '02', name: 'Software Development Co.', img: IMG.laptopCode },
  { n: '03', name: 'Freelancer Portfolio', img: IMG.portraitM2 },
  { n: '04', name: 'Digital Agency', img: IMG.abstract1 },
  { n: '05', name: 'Creative Design Studio', img: IMG.designTools },
  { n: '06', name: 'Personal Portfolio · alex walker 🔥', img: IMG.portraitM1, wide: true },
  { n: '07', name: 'Web Agency · Shaping ideas', img: IMG.workspace2, wide: true },
  { n: '08', name: 'Creative Developer', img: IMG.portraitW1 },
  { n: '09', name: 'Designer', img: IMG.abstract2 },
]

const fadeUp = {
  hidden: { opacity: 0, y: 50 },
  show: (i) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, delay: i * 0.06, ease: [0.16, 1, 0.3, 1] },
  }),
}

export default function WorksShowcase() {
  return (
    <section id="works" className="px-6 md:px-10 max-w-[1400px] mx-auto py-24">
      <div className="text-center mb-14">
        <SectionLabel>9 unique demos</SectionLabel>
        <h2 className="font-display text-4xl md:text-6xl font-semibold">
          Pick a style that fits your story
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
        {demos.map((d, i) => (
          <motion.div
            key={d.n}
            custom={i}
            variants={fadeUp}
            initial="hidden"
            whileInView="show"
            viewport={{ once: true, amount: 0.3 }}
            className={d.wide ? 'col-span-2' : ''}
          >
            <TiltCard maxTilt={5} className="h-40 md:h-48 rounded-2xl">
              <div className="group relative rounded-2xl border border-line overflow-hidden h-40 md:h-48 cursor-pointer">
                <img
                  src={d.img}
                  alt={d.name}
                  loading="lazy"
                  className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-black/20" />
                <div className="relative z-10 h-full flex flex-col justify-between p-5 text-white">
                  <div className="flex items-center justify-between text-xs text-white/70">
                    <span>rayo template</span>
                    <span>{d.n}</span>
                  </div>
                  <p className="font-display text-lg md:text-xl font-semibold leading-snug transition-transform duration-300 group-hover:translate-x-1">
                    {d.name}
                  </p>
                </div>
              </div>
            </TiltCard>
          </motion.div>
        ))}
      </div>

      <Marquee
        className="mt-16 -mx-6 md:-mx-10"
        items={['Digital Agency', 'Creative Studio', 'Designer', 'Developer', 'Freelancer']}
      />
    </section>
  )
}
