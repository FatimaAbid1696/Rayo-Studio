import { motion } from 'framer-motion'
import { Blob, Sphere, BrowserCard, TiltCard } from './UI'
import { IMG } from '../data/images'

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
}
const item = {
  hidden: { y: 40, opacity: 0 },
  show: { y: 0, opacity: 1, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } },
}

export default function Hero() {
  return (
    <section className="relative pt-40 pb-24 px-6 md:px-10 max-w-[1400px] mx-auto overflow-hidden">
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-32 left-1/2 -translate-x-1/2 w-[900px] h-[500px] rounded-full opacity-25 blur-3xl"
        style={{ background: 'radial-gradient(ellipse at center, #8C7EF5, transparent 70%)' }}
        animate={{ scale: [1, 1.08, 1], opacity: [0.2, 0.3, 0.2] }}
        transition={{ duration: 8, repeat: Infinity, ease: 'easeInOut' }}
      />
      <Blob className="hidden md:block absolute top-24 left-4 w-28 h-28 opacity-70" colorFrom="#fff" colorTo="#cfcfcf" />
      <Sphere className="hidden md:block absolute top-14 right-[14%] w-24 h-24" />

      <motion.div variants={container} initial="hidden" animate="show" className="text-center max-w-4xl mx-auto">
        <motion.h1 variants={item} className="font-display font-semibold text-[13vw] md:text-[5.4rem] leading-[0.98] tracking-tight">
          Make{' '}
          <span className="inline-block bg-violet text-cream px-4 rounded-full">
            work + your
          </span>
          <br />
          <span className="text-violet">✦</span> stand out
        </motion.h1>

        <motion.p variants={item} className="mt-8 text-ink/60 max-w-xl mx-auto text-lg">
          Elevate your digital presence with Rayo — a dynamic and stylish template
          designed for creative agencies and personal brands.
        </motion.p>

        <motion.div variants={item} className="mt-9 flex items-center justify-center gap-4">
          <a href="#works" className="bg-ink text-cream rounded-full px-7 py-3 text-sm font-medium hover:bg-violet transition-colors duration-300">
            View Works
          </a>
          <a href="/contact" className="border border-ink/20 rounded-full px-7 py-3 text-sm font-medium hover:bg-white transition-colors duration-300">
            Say Hello ↗
          </a>
        </motion.div>
      </motion.div>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="mt-16 grid md:grid-cols-2 gap-6"
      >
        <motion.div variants={item}>
          <TiltCard className="h-64 md:h-80">
            <BrowserCard title="rayo template" className="h-64 md:h-80" image={IMG.designTools}>
              <div className="h-full flex flex-col justify-end pb-6">
                <h3 className="font-display text-3xl md:text-4xl font-semibold leading-tight">
                  Design, <span className="bg-violet px-2 rounded-full">tech</span>
                  <br />
                  <span className="text-violet-light">✦</span> and some magic
                </h3>
              </div>
            </BrowserCard>
          </TiltCard>
        </motion.div>
        <motion.div variants={item}>
          <TiltCard className="h-64 md:h-80">
            <BrowserCard title="rayo template" tag="🔥 Hot" className="h-64 md:h-80 ring-2 ring-violet" image={IMG.astronaut}>
              <div className="h-full flex flex-col justify-end pb-6">
                <p className="text-xs uppercase tracking-wide text-white/70 mb-1">Cutting-edge software</p>
                <h3 className="font-display text-2xl md:text-3xl font-semibold">development company</h3>
              </div>
            </BrowserCard>
          </TiltCard>
        </motion.div>
      </motion.div>
    </section>
  )
}
