import { useRef } from 'react'
import { motion } from 'framer-motion'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { IMG } from '../data/images'

const cards = [
  { title: 'Creative solutions made simple', accent: 'bg-white', img: IMG.workspace1 },
  { title: '3D Artist', sub: "Hey! I'm Alex Walker. Passionate about crafting designs that tell stories, spark emotions and make an impact.", accent: 'bg-white ring-2 ring-violet', img: IMG.portraitM1 },
  { title: 'Driven by ideas and innovation', accent: 'bg-white', img: IMG.meeting },
]

export default function AboutCarousel() {
  const scrollerRef = useRef(null)

  const scrollBy = (dir) => {
    scrollerRef.current?.scrollBy({ left: dir * 340, behavior: 'smooth' })
  }

  return (
    <section id="about" className="px-6 md:px-10 max-w-[1400px] mx-auto py-16">
      <div
        ref={scrollerRef}
        className="flex gap-5 overflow-x-auto scroll-smooth snap-x pb-4 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
      >
        {cards.map((c, i) => (
          <motion.div
            key={c.title}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.1 }}
            className={`snap-start shrink-0 w-[320px] h-[380px] rounded-2xl border border-line p-6 flex flex-col justify-between ${c.accent}`}
          >
            <div className="flex items-center justify-between text-xs text-ink/50">
              <span>rayo template</span>
              <span>≡</span>
            </div>
            <div>
              <h3 className="font-display text-2xl font-semibold">{c.title}</h3>
              {c.sub && <p className="text-xs text-ink/50 mt-2">{c.sub}</p>}
            </div>
            <div className="relative h-32 rounded-xl overflow-hidden">
              <img src={c.img} alt="" loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-black/30 flex items-end p-3">
                <span className="text-xs text-white">approach & philosophy</span>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="flex items-center justify-center gap-6 mt-8">
        <button
          onClick={() => scrollBy(-1)}
          className="w-11 h-11 rounded-full border border-line flex items-center justify-center hover:bg-ink hover:text-cream transition-colors duration-300"
        >
          <ArrowLeft size={16} />
        </button>
        <p className="font-display text-lg">About Me</p>
        <button
          onClick={() => scrollBy(1)}
          className="w-11 h-11 rounded-full border border-line flex items-center justify-center hover:bg-ink hover:text-cream transition-colors duration-300"
        >
          <ArrowRight size={16} />
        </button>
      </div>
    </section>
  )
}
