import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Menu, X, Moon } from 'lucide-react'

const LINKS = [
  { label: 'Home', to: '/' },
  { label: 'Works', to: '/#works' },
  { label: 'Pages', to: '/#pages' },
  { label: 'Insights', to: '/#insights' },
  { label: 'Contact', to: '/contact' },
]

export default function Navbar({ dark }) {
  const [open, setOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className={`fixed top-0 left-0 right-0 z-50 transition-colors duration-300 ${
          scrolled ? 'bg-cream/80 backdrop-blur-md border-b border-line' : ''
        }`}
      >
        <div className="max-w-[1400px] mx-auto flex items-center justify-between px-6 md:px-10 py-5">
          <Link to="/" className="flex items-center gap-2.5 group">
            <span className="w-9 h-9 rounded-full bg-ink flex items-center justify-center text-cream text-sm font-display font-semibold group-hover:rotate-12 transition-transform duration-300">
              R
            </span>
            <span className="font-display text-sm leading-tight">
              rayo
              <br />
              template
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-1 bg-white/60 border border-line rounded-full px-2 py-2">
            {LINKS.map((l) => (
              <a
                key={l.label}
                href={l.to}
                className="text-sm px-4 py-1.5 rounded-full text-ink/70 hover:text-ink hover:bg-white transition-colors duration-200"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            <button
              aria-label="toggle theme"
              className="hidden sm:flex w-9 h-9 rounded-full border border-line items-center justify-center hover:bg-white transition-colors"
            >
              <Moon size={15} />
            </button>
            <Link
              to="/contact"
              className="hidden sm:inline-flex items-center gap-1.5 border border-ink rounded-full px-5 py-2 text-sm font-medium hover:bg-ink hover:text-cream transition-colors duration-300"
            >
              Say Hello ↗
            </Link>
            <button
              onClick={() => setOpen(true)}
              className="w-11 h-11 rounded-full bg-ink text-cream flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
              aria-label="open menu"
            >
              <Menu size={18} />
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ clipPath: 'circle(0% at 95% 5%)' }}
            animate={{ clipPath: 'circle(150% at 95% 5%)' }}
            exit={{ clipPath: 'circle(0% at 95% 5%)' }}
            transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-[90] bg-ink text-cream flex flex-col justify-between p-8 md:p-14"
          >
            <div className="flex items-center justify-between">
              <p className="text-sm text-white/50 flex items-center gap-2">
                ✦ Innovative design and cutting-edge development
              </p>
              <button
                onClick={() => setOpen(false)}
                className="w-11 h-11 rounded-full border border-white/20 flex items-center justify-center hover:bg-white/10"
              >
                <X size={18} />
              </button>
            </div>

            <div className="flex flex-col gap-2">
              {LINKS.map((l, i) => (
                <motion.a
                  key={l.label}
                  href={l.to}
                  onClick={() => setOpen(false)}
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.15 + i * 0.06, duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
                  className="font-display text-5xl md:text-7xl font-semibold hover:text-violet-light transition-colors duration-300 hover:pl-4"
                >
                  {l.label}
                </motion.a>
              ))}
            </div>

            <div className="flex justify-between text-xs text-white/40">
              <span>
                Made with ♥ by <span className="text-lime">Mix_Design</span>
              </span>
              <span>© 2026</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
