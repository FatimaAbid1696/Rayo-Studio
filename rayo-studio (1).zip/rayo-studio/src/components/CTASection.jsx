import { motion } from 'framer-motion'

export default function CTASection() {
  return (
    <section className="relative pt-24 pb-40 overflow-hidden">
      <div className="px-6 md:px-10 max-w-[1400px] mx-auto text-center relative z-10">
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.7 }}
          className="font-display text-4xl md:text-6xl font-semibold"
        >
          Show your creativity and
          <br />
          <span className="text-ink/30">get noticed today!</span>
        </motion.h2>
        <motion.a
          href="/contact"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.6, delay: 0.15 }}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.97 }}
          className="inline-flex items-center gap-2 bg-lime text-ink rounded-full px-8 py-4 text-sm font-semibold mt-8"
        >
          Buy Now 🛒
        </motion.a>
      </div>

      <svg
        className="absolute bottom-0 left-0 w-full h-64 md:h-80 -z-0"
        viewBox="0 0 1440 320"
        preserveAspectRatio="none"
      >
        <motion.path
          fill="#E7E1D8"
          animate={{
            d: [
              'M0,192L80,197.3C160,203,320,213,480,197.3C640,181,800,139,960,144C1120,149,1280,203,1360,229.3L1440,256L1440,320L0,320Z',
              'M0,224L80,213.3C160,203,320,181,480,192C640,203,800,245,960,240C1120,235,1280,181,1360,154.7L1440,128L1440,320L0,320Z',
              'M0,192L80,197.3C160,203,320,213,480,197.3C640,181,800,139,960,144C1120,149,1280,203,1360,229.3L1440,256L1440,320L0,320Z',
            ],
          }}
          transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut' }}
        />
      </svg>
    </section>
  )
}
