import { motion } from 'framer-motion'
import { IMG } from '../data/images'

const fadeUp = {
  hidden: { opacity: 0, y: 60 },
  show: { opacity: 1, y: 0, transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] } },
}

const portfolioTags = ['Stack cards', 'Grids', 'Archive list', 'Testimonials', 'Project']

export default function SplitShowcase() {
  return (
    <section className="px-6 md:px-10 max-w-[1400px] mx-auto py-8 grid md:grid-cols-2 gap-6">
      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.3 }}
        className="bg-white rounded-3xl border border-line p-10 text-center flex flex-col items-center"
      >
        <h3 className="font-display text-4xl font-semibold">Blog Pages</h3>
        <div className="flex gap-2 mt-4 mb-4">
          {['Ideas', 'Thoughts', 'Inspiration'].map((t) => (
            <span key={t} className="text-xs border border-line rounded-full px-3 py-1">{t}</span>
          ))}
        </div>
        <p className="text-ink/55 max-w-xs text-sm mb-8">
          A blog that looks good, reads better, and brings your stories to life beautifully.
        </p>
        <div className="relative w-full h-40 rounded-2xl border border-line overflow-hidden flex items-center justify-center">
          <img src={IMG.artStudio} alt="" loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-black/45" />
          <p className="relative font-display text-2xl px-6 text-center text-white">
            My journey into the future of art
          </p>
        </div>
      </motion.div>

      <motion.div
        variants={fadeUp}
        initial="hidden"
        whileInView="show"
        viewport={{ once: true, amount: 0.3 }}
        transition={{ delay: 0.15 }}
        className="rounded-3xl border border-line p-10 text-center flex flex-col items-center overflow-hidden relative bg-gradient-to-b from-[#F3EEE7] to-white"
      >
        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          className="absolute -top-6 right-6 w-40 h-40 rounded-full"
          style={{ background: 'radial-gradient(circle at 40% 30%, #FFD36B, #F5A623 60%, #E8871E 100%)' }}
        />
        <h3 className="font-display text-4xl font-semibold mt-24 relative">Portfolio</h3>
        <div className="flex gap-2 mt-4 mb-4 relative">
          {['Showcase', 'Visions', 'Designs'].map((t) => (
            <span key={t} className="text-xs border border-line rounded-full px-3 py-1 bg-white/70">{t}</span>
          ))}
        </div>
        <p className="text-ink/55 max-w-xs text-sm mb-8 relative">
          Bring your work to life with stunning layouts. Clear, stylish pages built to impress and inspire.
        </p>
        <div className="flex gap-3 relative">
          {portfolioTags.map((t, i) => (
            <motion.div
              key={t}
              whileHover={{ y: -4, scale: 1.08 }}
              className="w-11 h-11 rounded-full bg-violet flex items-center justify-center text-cream text-xs"
              title={t}
            >
              {i + 1}
            </motion.div>
          ))}
        </div>
      </motion.div>
    </section>
  )
}
