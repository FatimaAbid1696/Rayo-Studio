import { motion } from 'framer-motion'
import { ArrowUpRight } from 'lucide-react'
import { Marquee, Sphere, Blob } from './UI'

const socials = ['Dribbble', 'Behance', 'Instagram', 'Github', 'Codepen', 'Figma community']

const offices = [
  { city: 'New York', addr: '11 West 53 Street, New York, NY 10019', phone: '+1 212-708-9400' },
  { city: 'Oakland', addr: '3400 Broadway, Oakland, CA 94611', phone: '+1 510-457-0211' },
]

export default function ConnectSection() {
  return (
    <section id="insights" className="px-6 md:px-10 max-w-[1400px] mx-auto py-16">
      <Marquee items={['Connect', 'Connect', 'Connect']} speed={16} className="mb-8" />

      <div className="max-w-2xl mx-auto">
        {socials.map((s, i) => (
          <motion.a
            key={s}
            href="#"
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.5, delay: i * 0.05 }}
            className="flex items-center justify-between border-b border-line py-4 text-violet font-medium hover:pl-3 hover:text-ink transition-all duration-300"
          >
            {s} <ArrowUpRight size={16} />
          </motion.a>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-8 mt-16 max-w-3xl mx-auto">
        <motion.h3
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          className="font-display text-4xl font-semibold"
        >
          Welcome <span className="text-ink/30">to our office</span>
        </motion.h3>
        <div>
          <p className="text-sm text-ink/50 mb-6">
            Inspiring ideas, creative insights, and the latest in design and tech.
            Fueling innovation for your digital journey.
          </p>
          <div className="grid grid-cols-2 gap-6 text-sm">
            {offices.map((o) => (
              <div key={o.city}>
                <p className="font-medium mb-1">{o.city}</p>
                <p className="text-ink/50">{o.addr}</p>
                <p className="text-ink/50">{o.phone}</p>
                <p className="text-violet">hello@rayo.com</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      <motion.a
        href="/contact"
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.7 }}
        whileHover={{ scale: 1.01 }}
        className="relative mt-16 block rounded-3xl bg-ink text-cream p-10 md:p-14 overflow-hidden"
      >
        <Sphere className="hidden md:block absolute right-16 top-1/2 -translate-y-1/2 w-24 h-24" />
        <Blob className="hidden md:block absolute right-40 top-8 w-12 h-12 opacity-60" colorFrom="#fff" colorTo="#999" />
        <p className="font-display text-3xl md:text-5xl font-semibold max-w-lg">
          🤍 Let's talk about your project!
        </p>
        <span className="inline-flex items-center gap-2 bg-lime text-ink rounded-full px-6 py-3 text-sm font-semibold mt-6">
          Say Hello ↗
        </span>
      </motion.a>
    </section>
  )
}
