import { motion } from 'framer-motion'
import { Smartphone, Tablet, Laptop, Monitor } from 'lucide-react'
import { Marquee } from './UI'

const devices = [
  { icon: Smartphone, label: 'Smartphone' },
  { icon: Tablet, label: 'Tablet' },
  { icon: Laptop, label: 'Laptop' },
  { icon: Monitor, label: 'Desktop' },
]

export default function ResponsiveSection() {
  return (
    <section className="px-6 md:px-10 max-w-[1400px] mx-auto py-24">
      <div className="grid md:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <h2 className="font-display text-4xl md:text-5xl font-semibold leading-tight">
            Fully responsive and pixel-perfect
          </h2>
          <p className="text-ink/55 mt-4 max-w-md">
            Rayo looks great on any device. Your site stays stunning and functional
            everywhere.
          </p>
          <div className="flex gap-6 mt-8">
            {devices.map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-2">
                <div className="w-12 h-12 rounded-full border border-line flex items-center justify-center hover:bg-violet hover:text-cream hover:border-violet transition-colors duration-300">
                  <Icon size={18} />
                </div>
                <span className="text-xs text-ink/50">{label}</span>
              </div>
            ))}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.9, rotate: 4 }}
          whileInView={{ opacity: 1, scale: 1, rotate: 0 }}
          viewport={{ once: true, amount: 0.4 }}
          transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
          className="relative h-72 flex items-center justify-center"
        >
          <motion.div
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
            className="w-40 h-64 rounded-[2rem] bg-ink text-cream p-4 shadow-2xl -rotate-6 z-10"
          >
            <p className="font-display text-2xl leading-tight">
              Design <span className="bg-violet px-1 rounded">+ tech +</span> and some magic
            </p>
          </motion.div>
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 5.5, repeat: Infinity, ease: 'easeInOut', delay: 0.3 }}
            className="w-40 h-64 rounded-[2rem] bg-white border border-line p-4 shadow-2xl rotate-6 -ml-10 z-20"
          >
            <p className="text-xs text-ink/50 mb-2">Our capabilities</p>
            <div className="space-y-2">
              {['Software development', 'Web app development', 'UI/UX design'].map((t) => (
                <div key={t} className="bg-cream rounded-lg px-2 py-2 text-xs">{t}</div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>

      <Marquee className="mt-20" items={['Inner Pages', 'Inner Pages', 'Inner Pages']} speed={20} />
    </section>
  )
}
