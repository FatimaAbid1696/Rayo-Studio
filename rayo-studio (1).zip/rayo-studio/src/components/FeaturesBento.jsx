import { motion } from 'framer-motion'
import { SectionLabel } from './UI'
import { IMG } from '../data/images'

const fadeUp = {
  hidden: { opacity: 0, y: 40 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } },
}

export default function FeaturesBento() {
  return (
    <section id="pages" className="px-6 md:px-10 max-w-[1400px] mx-auto py-24">
      <div className="grid md:grid-cols-2 gap-10 items-end mb-12">
        <div>
          <SectionLabel>Animations · Plugins · Services</SectionLabel>
          <h2 className="font-display text-4xl md:text-5xl font-semibold leading-tight">
            Top-notch features,
            <br />
            build for you
          </h2>
        </div>
        <p className="text-ink/55 max-w-md md:justify-self-end">
          Rayo template packed with smooth animations, modern design tools and clean
          code. It's a flexible, future-proof template that's easy to customize and a
          joy to use.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-5">
        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }}
          className="relative md:col-span-2 border border-line rounded-2xl p-8 flex flex-col justify-between min-h-[220px] overflow-hidden"
        >
          <img src={IMG.laptopCode} alt="" loading="lazy" className="absolute inset-0 w-full h-full object-cover" />
          <div className="absolute inset-0 bg-white/85" />
          <div className="relative">
            <h3 className="font-display text-2xl font-semibold">Dynamic & stylish design</h3>
            <p className="text-sm text-ink/50 mt-2 max-w-sm">
              Modern, eye-catching layouts crafted to make your brand stand out and
              keep visitors engaged.
            </p>
          </div>
          <div className="relative flex gap-2 mt-6">
            {['Design', 'Layouts', 'Visuals'].map((t) => (
              <span key={t} className="text-xs border border-line rounded-full px-3 py-1 bg-white/70">{t}</span>
            ))}
          </div>
        </motion.div>

        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }} transition={{ delay: 0.1 }}
          className="bg-violet text-cream rounded-2xl p-8 flex flex-col justify-between min-h-[220px] relative overflow-hidden"
        >
          <motion.div
            animate={{ x: [0, 10, 0], y: [0, -6, 0] }}
            transition={{ duration: 5, repeat: Infinity }}
            className="absolute -top-4 -right-4 w-24 h-24 rounded-full bg-white/10"
          />
          <h3 className="font-display text-2xl font-semibold relative">Dark / light mode</h3>
          <p className="text-sm text-white/70 mt-2 relative">
            Switch effortlessly between light and dark modes for a user-friendly
            experience.
          </p>
        </motion.div>

        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }} transition={{ delay: 0.15 }}
          className="bg-[#DDF25A] rounded-2xl p-8 flex flex-col justify-between min-h-[200px]"
        >
          <h3 className="font-display text-2xl font-semibold">Easy to customize</h3>
          <p className="text-sm text-ink/60 mt-2">
            Adapt every detail to fit your vision — no fuss, just simple, clear
            editing.
          </p>
        </motion.div>

        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }} transition={{ delay: 0.2 }}
          className="bg-ink text-cream rounded-2xl p-8 flex flex-col justify-between min-h-[200px]"
        >
          <h3 className="font-display text-2xl font-semibold">GSAP-powered animations</h3>
          <p className="text-sm text-white/60 mt-2">
            Adding unique movement, scroll magic, and creative depth to your pages.
          </p>
        </motion.div>

        <motion.div
          variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }} transition={{ delay: 0.25 }}
          className="bg-[#EDE9FF] rounded-2xl p-8 flex flex-col justify-between min-h-[200px]"
        >
          <h3 className="font-display text-2xl font-semibold">Code excellence</h3>
          <p className="text-sm text-ink/60 mt-2">
            Built with clean, well-structured code that's fast, secure, and easy to
            maintain.
          </p>
        </motion.div>
      </div>
      <p className="text-center text-ink/40 text-sm mt-8">+ and much more +</p>
    </section>
  )
}
