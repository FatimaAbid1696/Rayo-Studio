import { motion } from 'framer-motion'
import { IMG } from '../data/images'

const tiles = [
  { title: '30+ Reviews', sub: '80% satisfaction', img: IMG.analytics },
  { title: 'Featured projects', sub: 'Mobile app design & 3D', img: IMG.phoneApp, dark: true },
  { title: 'Clients Approved', img: IMG.meeting },
  { title: 'Our capabilities', sub: 'Software · UI/UX · Testing', img: IMG.laptopDesk, dark: true },
  { title: 'Inspiring ideas', img: IMG.abstract1 },
  { title: 'Always on-trend creatives', img: IMG.designTools },
]

// A soft, continuously morphing blob (instead of a spinning polygon "stone")
// used as ambient decoration behind the heading.
function MorphBlob({ className, hue = '#8C7EF5', delay = 0 }) {
  const paths = [
    'M43.4,-58.4C55.6,-49.5,64.4,-35.6,68.6,-20.3C72.8,-5,72.4,11.7,66.1,25.9C59.8,40.1,47.6,51.8,33.4,59.2C19.2,66.6,3,69.7,-13.4,68.6C-29.8,67.5,-46.4,62.2,-57.6,50.9C-68.8,39.6,-74.6,22.3,-75.1,4.6C-75.6,-13.1,-70.8,-31.2,-59.8,-43.6C-48.8,-56,-31.6,-62.7,-14.5,-64.7C2.6,-66.7,20.9,-63.9,43.4,-58.4Z',
    'M39.6,-52.7C50.6,-45.3,58.5,-32.6,63.2,-18.4C67.9,-4.2,69.4,11.5,64.3,24.8C59.2,38.1,47.5,49,34.1,57.1C20.7,65.2,5.6,70.5,-9.9,70.6C-25.4,70.7,-41.3,65.6,-52.6,54.9C-63.9,44.2,-70.6,27.9,-72.3,10.9C-74,-6.1,-70.7,-23.8,-61.4,-37.4C-52.1,-51,-36.8,-60.5,-21.1,-66.2C-5.4,-71.9,10.7,-73.8,39.6,-52.7Z',
    'M43.4,-58.4C55.6,-49.5,64.4,-35.6,68.6,-20.3C72.8,-5,72.4,11.7,66.1,25.9C59.8,40.1,47.6,51.8,33.4,59.2C19.2,66.6,3,69.7,-13.4,68.6C-29.8,67.5,-46.4,62.2,-57.6,50.9C-68.8,39.6,-74.6,22.3,-75.1,4.6C-75.6,-13.1,-70.8,-31.2,-59.8,-43.6C-48.8,-56,-31.6,-62.7,-14.5,-64.7C2.6,-66.7,20.9,-63.9,43.4,-58.4Z',
  ]
  return (
    <motion.svg viewBox="-80 -80 160 160" className={`absolute ${className}`}>
      <motion.path
        fill={hue}
        fillOpacity={0.7}
        animate={{ d: paths, rotate: [0, 20, 0] }}
        transition={{ duration: 10, repeat: Infinity, ease: 'easeInOut', delay }}
        style={{ transformOrigin: 'center' }}
      />
    </motion.svg>
  )
}

export default function FunctionalComponents() {
  return (
    <section className="px-6 md:px-10 max-w-[1400px] mx-auto py-24 relative">
      <div className="text-center relative mb-14">
        <MorphBlob className="w-28 h-28 -left-2 top-0 md:left-16 blur-[2px]" hue="#C99A6A" delay={0} />
        <MorphBlob className="w-16 h-16 right-2 top-20 md:right-32 blur-[1px]" hue="#8C7EF5" delay={2} />
        <h2 className="font-display text-5xl md:text-7xl font-semibold relative z-10">
          Functional
          <br />
          components
        </h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
        {tiles.map((t, i) => (
          <motion.div
            key={t.title}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.07 }}
            whileHover={{ y: -6, scale: 1.02 }}
            className="group relative rounded-2xl border border-line overflow-hidden h-40"
          >
            <img
              src={t.img}
              alt=""
              loading="lazy"
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/75 via-black/5 to-black/0" />
            <div className="relative z-10 h-full flex flex-col justify-between p-5 text-white">
              <span className="text-xs text-white/70">rayo template</span>
              <div>
                <p className="font-display text-lg font-semibold">{t.title}</p>
                {t.sub && <p className="text-xs text-white/70 mt-1">{t.sub}</p>}
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  )
}
