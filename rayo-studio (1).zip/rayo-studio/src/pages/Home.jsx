import Hero from '../components/Hero'
import WorksShowcase from '../components/WorksShowcase'
import SplitShowcase from '../components/SplitShowcase'
import ResponsiveSection from '../components/ResponsiveSection'
import AboutCarousel from '../components/AboutCarousel'
import StatsMarquee from '../components/StatsMarquee'
import FunctionalComponents from '../components/FunctionalComponents'
import FeaturesBento from '../components/FeaturesBento'
import CTASection from '../components/CTASection'
import ConnectSection from '../components/ConnectSection'

export default function Home() {
  return (
    <>
      <Hero />
      <WorksShowcase />
      <SplitShowcase />
      <ResponsiveSection />
      <AboutCarousel />
      <StatsMarquee />
      <FunctionalComponents />
      <FeaturesBento />
      <CTASection />
      <ConnectSection />
    </>
  )
}
