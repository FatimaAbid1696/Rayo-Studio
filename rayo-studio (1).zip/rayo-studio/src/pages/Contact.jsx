import { useState } from 'react'
import { motion } from 'framer-motion'
import { Sphere, Blob } from '../components/UI'

const fields = [
  { name: 'name', label: 'Your name*', type: 'text' },
  { name: 'company', label: 'Company name', type: 'text' },
  { name: 'email', label: 'Email*', type: 'email' },
  { name: 'phone', label: 'Phone', type: 'text' },
]

export default function Contact() {
  const [sent, setSent] = useState(false)
  const [values, setValues] = useState({})

  const handleSubmit = (e) => {
    e.preventDefault()
    setSent(true)
  }

  return (
    <section className="pt-40 pb-24 px-6 md:px-10 max-w-[1400px] mx-auto">
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-xs text-violet mb-3 flex items-center gap-1.5"
      >
        <span className="w-1.5 h-1.5 rounded-full bg-violet inline-block" /> Contact
      </motion.p>

      <motion.h1
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        className="font-display text-5xl md:text-7xl font-semibold leading-tight"
      >
        Let's talk
        <br />
        about your project!
      </motion.h1>
      <motion.a
        href="mailto:hello@rayo.com"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="font-display text-3xl md:text-5xl font-semibold text-ink/20 hover:text-violet transition-colors duration-300 inline-block mt-2"
      >
        hello@rayo.com ↗
      </motion.a>

      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.35, duration: 0.6 }}
        className="text-ink/55 max-w-lg mt-6"
      >
        Have questions? We've got the answers! Here, you'll find clear and concise
        information about our services, process, and what to expect when working
        with us. If you need more details, feel free to reach out!
      </motion.p>

      {sent ? (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-10 max-w-md bg-white border border-line rounded-2xl p-8"
        >
          <p className="font-display text-2xl font-semibold mb-2">Message sent ✦</p>
          <p className="text-ink/55 text-sm">
            Thanks for reaching out — we'll get back to you shortly.
          </p>
        </motion.div>
      ) : (
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45, duration: 0.7 }}
          className="mt-10 max-w-2xl grid sm:grid-cols-2 gap-x-8 gap-y-6"
        >
          {fields.map((f) => (
            <label key={f.name} className="block">
              <span className="text-xs text-ink/40">{f.label}</span>
              <input
                type={f.type}
                required={f.label.includes('*')}
                onChange={(e) => setValues((v) => ({ ...v, [f.name]: e.target.value }))}
                className="w-full bg-transparent border-b border-line focus:border-violet outline-none py-2 transition-colors duration-300"
              />
            </label>
          ))}
          <label className="block sm:col-span-2">
            <span className="text-xs text-ink/40">A few words about your project*</span>
            <input
              type="text"
              required
              onChange={(e) => setValues((v) => ({ ...v, message: e.target.value }))}
              className="w-full bg-transparent border-b border-line focus:border-violet outline-none py-2 transition-colors duration-300"
            />
          </label>

          <motion.button
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.96 }}
            type="submit"
            className="sm:col-span-2 justify-self-start bg-ink text-cream rounded-full px-7 py-3 text-sm font-medium flex items-center gap-2 hover:bg-violet transition-colors duration-300"
          >
            Submit ↗
          </motion.button>
        </motion.form>
      )}

      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true, amount: 0.3 }}
        transition={{ duration: 0.8 }}
        className="relative mt-20 h-72 rounded-3xl bg-ink overflow-hidden flex items-center justify-center"
      >
        <Sphere className="w-28 h-28" />
        <Blob className="absolute left-16 top-10 w-16 h-16 opacity-70" colorFrom="#fff" colorTo="#8C7EF5" />
      </motion.div>
    </section>
  )
}
