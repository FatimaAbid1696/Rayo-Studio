// Central image bank. Using Unsplash's CDN directly (images.unsplash.com) with
// size params — these load from the visitor's browser, not the build machine.
const u = (id, w = 800) => `https://images.unsplash.com/${id}?auto=format&fit=crop&w=${w}&q=70`

export const IMG = {
  nebula: u('photo-1462331940025-496dfbfc7564'),
  galaxyPurple: u('photo-1502134249126-9f3755a50d78'),
  astronaut: u('photo-1531306728370-e2ebd9d7bb99'),
  earthSpace: u('photo-1451187580459-43490279c0fa'),
  workspace1: u('photo-1517245386807-bb43f82c33c4'),
  workspace2: u('photo-1522199755839-a2bacb67c546'),
  laptopCode: u('photo-1498050108023-c5249f4df085'),
  laptopDesk: u('photo-1531297484001-80022131f5a1'),
  analytics: u('photo-1460925895917-afdab827c52f'),
  designTools: u('photo-1561070791-2526d30994b5'),
  paintPalette: u('photo-1502691876148-a84978e59af8'),
  artStudio: u('photo-1513364776144-60967b0f800f'),
  ceramics: u('photo-1493106641515-6b5631de4bb9'),
  portraitW1: u('photo-1607746882042-944635dfe10e'),
  portraitM1: u('photo-1500648767791-00dcc994a43e'),
  portraitW2: u('photo-1580489944761-15a19d654956'),
  portraitM2: u('photo-1519085360753-af0119f7cbe7'),
  cityNight: u('photo-1477959858617-67f85cf4f1df'),
  abstract1: u('photo-1550684376-efcbd6e3f031'),
  abstract2: u('photo-1620121692029-d088224ddc74'),
  abstract3: u('photo-1618172193622-ae2d025f4032'),
  meeting: u('photo-1522071820081-009f0129c71c'),
  coffee: u('photo-1521017432531-fbd92d768814'),
  phoneApp: u('photo-1512941937669-90a1b58e7e9c'),
  ecommerce: u('photo-1556740738-b6a63e27c4df'),
}
