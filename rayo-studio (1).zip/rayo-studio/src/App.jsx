import { useState } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'framer-motion'
import Loader from './components/Loader'
import Navbar from './components/Navbar'
import Home from './pages/Home'
import Contact from './pages/Contact'

export default function App() {
  const [loading, setLoading] = useState(true)
  const [curtain, setCurtain] = useState(true)
  const location = useLocation()

  const handleLoaderDone = () => {
    setLoading(false)
    setTimeout(() => setCurtain(false), 50)
  }

  return (
    <>
      {loading && <Loader onDone={handleLoaderDone} />}

      <AnimatePresence>
        {curtain && !loading && (
          <motion.div
            key="curtain"
            initial={{ y: 0 }}
            animate={{ y: '-100%' }}
            exit={{ y: '-100%' }}
            transition={{ duration: 1, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-[95] bg-ink"
          />
        )}
      </AnimatePresence>

      {!loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
        >
          <Navbar />
          <AnimatePresence mode="wait">
            <motion.main
              key={location.pathname}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            >
              <Routes location={location}>
                <Route path="/" element={<Home />} />
                <Route path="/contact" element={<Contact />} />
              </Routes>
            </motion.main>
          </AnimatePresence>
        </motion.div>
      )}
    </>
  )
}
