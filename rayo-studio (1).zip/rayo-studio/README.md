# Rayo Studio — React Clone

A single-page React clone of the Rayo Envato template, rebuilt with the same
cream/violet/lime color system and typography, plus an animated intro loader
(0→100% counter → curtain reveal), scroll-triggered reveals, a marquee system,
a full-screen animated menu, and a floating hero.

## Structure

- Everything lives on **one page** (`/`) — Hero, Works showcase, Blog/Portfolio
  split, Responsive/device section, About carousel, Stats marquee, Functional
  components, Features bento grid, CTA, Connect/office, Footer.
- **Contact** is its own route (`/contact`) with a working (client-side) form.

## Run it

npm install
npm run dev       # http://localhost:5173

## Build for production

npm run build      # outputs to /dist
npm run preview    # preview the production build

## Stack

- React 19 + Vite
- React Router (route-level page transitions)
- Framer Motion (loader, curtain reveal, scroll reveals, hover/tap micro-interactions, marquees)
- Tailwind CSS v4 (design tokens in src/index.css)
- lucide-react (icons)

## Customizing

- Colors/fonts: src/index.css (@theme block) — cream #F6F1EC, ink #121212,
  violet #8C7EF5, lime #D8FF4F.
- Loader timing: src/components/Loader.jsx.
- Section content/copy: each section is its own file in src/components/.
